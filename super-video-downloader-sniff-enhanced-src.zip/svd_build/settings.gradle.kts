pluginManagement {
    repositories {
        // Resolve plugin marker artifacts from Maven Central first: the Gradle
        // Plugin Portal (plugins.gradle.org) is not reachable from this build
        // host, so relying on it alone makes plugin resolution fail.
        mavenCentral()
        google()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven(url = "https://jitpack.io")
    }
}

rootProject.name = "super-video-downloader"
include(":app")
