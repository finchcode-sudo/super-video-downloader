/*
 * Enhanced in-page media scanner (rule C).
 *
 * Loaded as an asset and injected via evaluateJavascript() so its source is
 * never embedded - and therefore never mangled - inside a Kotlin string.
 *
 * Responsibilities, in order of importance:
 *   1. Report every media URL found in the page (HTML, inline <script>,
 *      data-* attributes, <video>/<source>/<audio> elements).
 *   2. Catch URLs the instant a player assigns them (property setters,
 *      load()), which happens before the browser issues the request.
 *   3. Scan XHR/fetch response bodies (JSON/JS/playlists) for embedded URLs.
 *   4. Normalise JSON-escaped URLs ("https:\/\/cdn\/x.m3u8", "\u002F").
 *
 * All backslashes are built at runtime (String.fromCharCode(92)) so the
 * script survives any host-level escaping untouched.
 */
(function () {
    if (window.__svd_media_scanner_installed) return;
    window.__svd_media_scanner_installed = true;

    var BS = String.fromCharCode(92);                 // backslash
    var D = BS + BS;                                  // two backslashes (regex: one literal backslash)
    var SEP = '[' + D + '/]';                         // backslash or slash
    // Character class excluding whitespace, quotes, angle brackets, backslash.
    // BS + 's' is the regex whitespace escape \s; D is a literal backslash.
    var NOT = '[^' + BS + 's"<>' + D + ']';
    var EXTS = 'm3u8|mpd|mp4|m4v|m4s|ts|f4m|f4v|mov|mkv|webm|flv|avi|3gp|ogv|' +
        'wmv|mpg|mpeg|m2ts|mp3|m4a|m4b|aac|flac|wav|ogg|opus|oga|wma|amr';

    var MEDIA_RE = new RegExp(
        'https?:' + SEP + '{2}' + NOT + '+?[.](' + EXTS + ')(?:[?]' + NOT + '*)?',
        'gi'
    );

    var seen = Object.create(null);

    // ---- JSON escape normalisation -------------------------------------
    // Applied to the WHOLE text BEFORE matching, so escaped URLs
    // ("https:\/\/cdn\/x.m3u8", "https:\u002F\u002Fx.mp4") become plain ones
    // and the (backslash-excluding) regex can see them.
    var RE_UNI_SLASH = new RegExp(D + 'u002[fF]', 'g');
    var RE_UNI_AMP = new RegExp(D + 'u0026', 'g');
    var RE_UNI_EQ = new RegExp(D + 'u003[dD]', 'g');
    var RE_UNI_Q = new RegExp(D + 'u003[fF]', 'g');
    var RE_ESC_SLASH = new RegExp(D + '/', 'g');

    function preNormalize(t) {
        return t.replace(RE_UNI_SLASH, '/')
                .replace(RE_UNI_AMP, '&')
                .replace(RE_UNI_EQ, '=')
                .replace(RE_UNI_Q, '?')
                .replace(RE_ESC_SLASH, '/');
    }

    function report(raw) {
        try {
            if (!raw || typeof raw !== 'string') return;
            var u = raw.split('#')[0];
            if (u.indexOf('http') !== 0) return;
            if (seen[u]) return;
            seen[u] = 1;
            if (window.AndroidBridge && window.AndroidBridge.reportMediaUrl) {
                window.AndroidBridge.reportMediaUrl(u);
            }
        } catch (e) { /* ignore */ }
    }

    // ---- text scanning --------------------------------------------------
    function scanText(text) {
        if (!text || typeof text !== 'string') return;
        text = preNormalize(text);
        MEDIA_RE.lastIndex = 0;
        var m;
        while ((m = MEDIA_RE.exec(text)) !== null) {
            report(m[0]);
        }
    }

    // ---- attribute / element scanning -----------------------------------
    var ATTRS = ['src', 'data-src', 'data-url', 'data-video', 'data-video-src',
        'data-mp4', 'data-hls', 'data-file', 'data-source', 'data-stream',
        'content', 'href'];
    var SEL = 'video, source, audio, track, embed, object, iframe, meta, a, link,' +
        '[data-src], [data-url], [data-video], [data-file], [data-stream]';

    function scanAttrs() {
        try {
            document.querySelectorAll(SEL).forEach(function (el) {
                for (var i = 0; i < ATTRS.length; i++) {
                    var v = null;
                    try { v = el.getAttribute ? el.getAttribute(ATTRS[i]) : null; } catch (e) {}
                    if (v) report(v);
                }
                try { if (el.src) report(el.src); } catch (e) {}
                try { if (el.currentSrc) report(el.currentSrc); } catch (e) {}
            });
        } catch (e) { /* ignore */ }
    }

    function scanScripts() {
        try {
            var buf = '';
            document.querySelectorAll('script').forEach(function (el) {
                if (el.textContent) buf += '\n' + el.textContent;
            });
            scanText(buf);
        } catch (e) { /* ignore */ }
    }

    function scanDocument() {
        try { scanText(document.documentElement ? document.documentElement.outerHTML : ''); } catch (e) {}
        try { scanText(document.body ? document.body.innerHTML : ''); } catch (e) {}
        scanScripts();
        scanAttrs();
    }

    // ---- hook media element src / load ---------------------------------
    try {
        var proto = HTMLMediaElement.prototype;
        var desc = Object.getOwnPropertyDescriptor(proto, 'src') ||
            Object.getOwnPropertyDescriptor(Element.prototype, 'src');
        if (desc && desc.set) {
            Object.defineProperty(proto, 'src', {
                get: desc.get,
                set: function (value) {
                    report(value);
                    return desc.set.call(this, value);
                },
                configurable: true
            });
        }
    } catch (e) { /* ignore */ }

    try {
        var origLoad = HTMLMediaElement.prototype.load;
        if (origLoad) {
            HTMLMediaElement.prototype.load = function () {
                try { if (this.src) report(this.src); } catch (e) {}
                return origLoad.apply(this, arguments);
            };
        }
    } catch (e) { /* ignore */ }

    // ---- hook XHR / fetch bodies ----------------------------------------
    try {
        var origOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function () {
            try { this.__svd_url = arguments[1]; } catch (e) {}
            return origOpen.apply(this, arguments);
        };
        var origSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.send = function () {
            var self = this;
            try {
                self.addEventListener('load', function () {
                    try {
                        var ct = self.getResponseHeader('Content-Type') || '';
                        if (/json|text|javascript|xml|mpegurl|plain/i.test(ct) || ct === '') {
                            scanText(self.responseText);
                        }
                    } catch (e) {}
                });
            } catch (e) {}
            return origSend.apply(this, arguments);
        };
    } catch (e) { /* ignore */ }

    try {
        var origFetch = window.fetch;
        if (origFetch) {
            window.fetch = function () {
                var args = arguments;
                return origFetch.apply(this, args).then(function (resp) {
                    try {
                        var ct = (resp.headers && resp.headers.get('Content-Type')) || '';
                        if (/json|text|javascript|xml|mpegurl|plain/i.test(ct) || ct === '') {
                            resp.clone().text().then(scanText).catch(function () {});
                        }
                    } catch (e) {}
                    return resp;
                });
            };
        }
    } catch (e) { /* ignore */ }

    // ---- observe DOM mutations ------------------------------------------
    try {
        var observer = new MutationObserver(function () { scanDocument(); });
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: true
        });
    } catch (e) { /* ignore */ }

    // Initial + scheduled sweeps.
    scanDocument();
    setTimeout(scanDocument, 800);
    setTimeout(scanDocument, 1500);
    setTimeout(scanDocument, 4000);
    setTimeout(scanDocument, 8000);
})();