package com.myAllVideoBrowser.ui.main.home.browser

import com.myAllVideoBrowser.data.local.model.SiteRule

/**
 * hikerView-style per-site sniffing rules - no settings UI, this file IS
 * the UI. To add a rule for a new site, add another SiteRule() entry below.
 *
 * Each rule:
 *  - urlPattern: a regex matched against the page URL. The rule only runs
 *    on pages whose URL matches.
 *  - script: JS that runs inside the page itself (same `document`/`window`
 *    the page's own scripts see). Call reportVideo(url) for every media URL
 *    found; it's fed into the same detection pipeline as everything else
 *    (network sniffing, the generic DOM scanner), so results show up in the
 *    detected-videos list the normal way.
 *
 * Keep scripts defensive - wrap risky lookups in try/catch inside your
 * script too, since one bad site can change its page structure at any time.
 *
 * --- Enhanced (this build) ---
 *  D. A generic "catch-all" rule that runs on EVERY page and does a deeper
 *     regex sweep (wider extension set + escaped-slash JSON + data-* attrs)
 *     than the built-in scanner, plus per-site templates for common sites.
 */
object SiteRules {

    /**
     * Shared JS snippet reused by the generic rule and the site templates.
     * It scans (a) the whole document HTML, (b) every inline <script>, and
     * (c) common lazy-load attributes, feeding everything it finds to
     * reportVideo() with escaped-slash / unicode normalisation.
     */
    private const val SHARED_SWEEP = """
        function __svdReport(u) {
            try {
                if (!u || typeof u !== 'string') return;
                u = u.split('#')[0].replace(/\\\\u002F/gi, '/').replace(/\\\\u0026/gi, '&').replace(/\\\\u003D/gi, '=').replace(/\\\\u003F/gi, '?').replace(/\\\\\//g, '/');
                if (u.indexOf('http') !== 0) return;
                reportVideo(u);
            } catch (e) {}
        }
        function __svdSweep(text) {
            if (!text) return;
            text = text.replace(/\\\\u002F/gi, '/').replace(/\\\\u0026/gi, '&').replace(/\\\\u003D/gi, '=').replace(/\\\\u003F/gi, '?').replace(/\\\\\//g, '/');
            var re = /https?:[\\\\/]{2}[^\s"'<>\\\\]+?\.(?:m3u8|mpd|mp4|m4v|m4s|ts|f4m|f4v|mov|mkv|webm|flv|avi|3gp|ogv|wmv|mpg|mpeg|m2ts|mp3|m4a|m4b|aac|flac|wav|ogg|opus|oga|wma|amr)(?:\?[^\s"'<>\\\\]*)?/gi;
            var m;
            while ((m = re.exec(text)) !== null) { __svdReport(m[0]); }
        }
        function __svdDeepScan() {
            try { __svdSweep(document.documentElement.outerHTML); } catch (e) {}
            try { __svdSweep(document.body.innerHTML); } catch (e) {}
            try {
                var s = '';
                document.querySelectorAll('script').forEach(function (el) { if (el.textContent) s += '\n' + el.textContent; });
                __svdSweep(s);
            } catch (e) {}
            try {
                var ATTRS = ['src', 'data-src', 'data-url', 'data-video', 'data-video-src', 'data-mp4', 'data-hls', 'data-file', 'data-source', 'data-stream', 'content', 'href'];
                document.querySelectorAll('video, source, audio, track, embed, object, iframe, meta, a, link, [data-src], [data-url], [data-video], [data-file], [data-stream]').forEach(function (el) {
                    for (var i = 0; i < ATTRS.length; i++) {
                        try { var v = el.getAttribute ? el.getAttribute(ATTRS[i]) : null; if (v) __svdReport(v); } catch (e) {}
                    }
                });
            } catch (e) {}
        }
    """

    val ALL: List<SiteRule> = listOf(
        // -------------------------------------------------------------------
        // Generic, always-on rule: deep sweep on every page. Uses a wider
        // extension set and normalises escaped JSON URLs. Disable only if it
        // ever produces noise on a specific device.
        // -------------------------------------------------------------------
        SiteRule(
            name = "Generic deep media sweep (all sites)",
            urlPattern = "https?://.*",
            script = """
                $SHARED_SWEEP
                __svdDeepScan();
                setTimeout(__svdDeepScan, 800);
                setTimeout(__svdDeepScan, 2000);
                setTimeout(__svdDeepScan, 5000);
                try {
                    new MutationObserver(function () { __svdDeepScan(); }).observe(document.documentElement, {
                        childList: true, subtree: true, attributes: true
                    });
                } catch (e) {}
            """.trimIndent(),
            enabled = true
        ),

        // Example / template - disabled by default. Copy this block to add
        // a real rule; set enabled = true once the script is written.
        SiteRule(
            name = "Example (template, disabled)",
            urlPattern = "https?://example\\.com/.*",
            script = """
                // Example: find the first .m3u8 URL sitting anywhere in the
                // page's HTML source and report it.
                var match = document.documentElement.outerHTML.match(/https?:[^"'<>\s]+\.(?:m3u8|mpd)[^"'<>\s]*/);
                if (match) {
                    reportVideo(match[0]);
                }
            """.trimIndent(),
            enabled = false
        )
    )
}