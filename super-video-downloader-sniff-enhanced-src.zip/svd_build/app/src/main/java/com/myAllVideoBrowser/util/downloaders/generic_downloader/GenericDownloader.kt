package com.myAllVideoBrowser.util.downloaders.generic_downloader

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.work.*
import com.myAllVideoBrowser.data.local.room.entity.VideoInfo
import com.myAllVideoBrowser.util.AppLogger
import com.myAllVideoBrowser.util.ContextUtils
import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import java.util.zip.Inflater
import androidx.core.content.edit
import com.antonkarpenko.ffmpegkit.FFmpegKit
import com.myAllVideoBrowser.util.FileUtil


abstract class GenericDownloader : IDownloader {
    companion object {
        private var instance: GenericDownloader? = null

        fun killWorkerAndRemoveData(context: Context, workId: String, fileUtil: FileUtil) {
            try {
                AppLogger.d("killWorker: Attempting to kill work with ID: $workId")
                WorkManager.getInstance(context).cancelUniqueWork(workId)
                cancelFfmpegTaskById(workId)
                fileUtil.tmpDir.resolve(workId).deleteRecursively()
            } catch (e: Exception) {
                AppLogger.e("killWorker: Failed to cancel work $workId")
                e.printStackTrace()
            }
        }

        fun cancelFfmpegTaskById(id: String) {
            try {
                val found = FFmpegKit.listSessions().firstOrNull { session ->
                    val argumentWithTaskId =
                        session.arguments.firstOrNull { arg -> arg.contains(id) }
                    argumentWithTaskId.isNullOrEmpty().not()
                }
                if (found != null) {
                    FFmpegKit.cancel(found.sessionId)
                }
            } catch (e: Throwable) {
                AppLogger.e("ERORR CANCEL FFMPEG TASK with id $id ${e.message}")
            }
        }

        fun isWorkScheduled(context: Context, uniqueWorkName: String): Boolean {
            val workManager = WorkManager.getInstance(context)
            try {
                // This is a blocking call, but it's okay inside a worker's background thread.
                val workInfos = workManager.getWorkInfosForUniqueWork(uniqueWorkName).get()
                if (workInfos.isNullOrEmpty()) {
                    return false
                }
                // Check if any of the work info states is "active" (not finished, cancelled, or failed)
                return workInfos.any { !it.state.isFinished }
            } catch (e: Throwable) {
                // Handle exceptions, e.g., if the get() is interrupted
                AppLogger.e("isWorkScheduled: Error checking work status for $uniqueWorkName")
                e.printStackTrace()
                return false // Assume not running if we can't check
            }
        }

        fun getInstance(): GenericDownloader {
            if (instance == null) {
                instance = object : GenericDownloader() {
                    override fun getDownloadDataFromVideoInfo(videoInfo: VideoInfo): Data.Builder {
                        throw UnsupportedOperationException("getDownloadDataFromVideoInfo not implemented")
                    }

                    override fun getWorkRequest(id: String): OneTimeWorkRequest.Builder {
                        throw UnsupportedOperationException("getWorkRequest not implemented")
                    }

                    override fun stopAndSaveDownload(
                        context: Context,
                        videoInfo: VideoInfo
                    ) {
                        throw UnsupportedOperationException("stopAndSaveDownload not implemented")
                    }
                }
            }

            return instance!!
        }
    }


    class Constants {
        companion object {
            const val ACTION_KEY = "ACTION_KEY"
            const val URL_KEY = "URL_KEY"
            const val FILENAME_KEY = "FILENAME_KEY"
            const val IS_FILE_REMOVE_KEY = "IS_FILE_REMOVE"
            const val TITLE_KEY = "TITLE_KEY"
            const val ORIGIN_KEY = "ORIGIN_KEY"
            const val TASK_ID_KEY = "TASK_ID"
            const val DURATION = "DURATION"
            const val IS_M3U8 = "IS_M3U8"
            const val IS_MPD = "IS_MPD"
            const val SELECTED_FORMAT_ID = "SELECTED_FORMAT_ID"
            const val PAIRED_AUDIO_ONLY_URL = "PAIRED_AUDIO_ONLY_URL"
            const val IS_LIVE = "IS_LIVE"
            const val VIDEO_CODEC = "VIDEO_CODEC"
            const val IS_AUDIO_ONLY_EXTRACT = "IS_AUDIO_ONLY_EXTRACT"
        }
    }

    class DownloaderActions {
        companion object {
            const val DOWNLOAD = "DOWNLOAD"
            const val PAUSE = "PAUSE"
            const val CANCEL = "CANCEL"
            const val RESUME = "RESUME"
            const val STOP_SAVE_ACTION = "STOP_SAVE_ACTION"
        }
    }

    abstract fun getDownloadDataFromVideoInfo(videoInfo: VideoInfo): Data.Builder


    abstract fun getWorkRequest(id: String): OneTimeWorkRequest.Builder

    override fun startDownload(context: Context, videoInfo: VideoInfo) {
        val downloadWork = getWorkRequest(videoInfo.id)

        val downloaderData = getDownloadDataFromVideoInfo(videoInfo)
        downloaderData.putString(Constants.ACTION_KEY, DownloaderActions.DOWNLOAD)
        downloaderData.putBoolean(Constants.IS_LIVE, videoInfo.isLive)
        downloadWork.setInputData(downloaderData.build())

        runWorkerTask(
            context,
            videoInfo,
            downloadWork.build()
        )

    }

    override fun cancelDownload(context: Context, videoInfo: VideoInfo, removeFile: Boolean) {
        val downloadWork = getWorkRequest(videoInfo.id)
        val downloaderData = getDownloadDataFromVideoInfo(videoInfo)
        downloaderData.putString(Constants.ACTION_KEY, DownloaderActions.CANCEL)
        downloaderData.putString(Constants.IS_FILE_REMOVE_KEY, removeFile.toString())
        downloadWork.setInputData(downloaderData.build())

        runWorkerTask(
            context,
            videoInfo,
            downloadWork.build()
        )
    }

    override fun pauseDownload(context: Context, videoInfo: VideoInfo) {
        val downloadWork = getWorkRequest(videoInfo.id)

        val downloaderData = getDownloadDataFromVideoInfo(videoInfo)
        downloaderData.putString(Constants.ACTION_KEY, DownloaderActions.PAUSE)
        downloadWork.setInputData(downloaderData.build())

        runWorkerTask(
            context,
            videoInfo,
            downloadWork.build()
        )
    }

    override fun resumeDownload(context: Context, videoInfo: VideoInfo) {
        val downloadWork = getWorkRequest(videoInfo.id)

        val downloaderData = getDownloadDataFromVideoInfo(videoInfo)
        downloaderData.putString(Constants.ACTION_KEY, DownloaderActions.RESUME)
        downloadWork.setInputData(downloaderData.build())

        runWorkerTask(
            context,
            videoInfo,
            downloadWork.build()
        )
    }

    override fun isWorkScheduled(context: Context, uniqueWorkName: String): Boolean {
        return Companion.isWorkScheduled(context, uniqueWorkName)
    }

    fun saveStringToSharedPreferences(
        context: Context,
        workId: String?,
        headersString: String
    ) {
        if (workId == null) {
            return
        }
        getDownloaderPreferences(context).edit {
            putString(workId, headersString)
        }
        AppLogger.d("saveHeadersStringToSharedPreferences  $workId")
    }

    fun loadHeadersStringFromSharedPreferences(context: Context, workId: String?): String? {
        AppLogger.d("loadHeadersStringFromSharedPreferences  $workId")

        if (workId == null) {
            return null
        }

        return getDownloaderPreferences(context).getString(
            workId,
            null
        )
    }

    fun deleteHeadersStringFromSharedPreferences(context: Context, workId: String?) {
        if (workId == null) {
            return
        }

        getDownloaderPreferences(context).edit {
            remove(workId)
        }
        AppLogger.d("deleteHeadersStringFromSharedPreferences  $workId")
    }

    fun compressString(text: String): String {
        val deflater = Deflater()
        deflater.setInput(text.toByteArray())
        deflater.finish()
        val buffer = ByteArray(text.length)
        val byteArrayOutputStream = ByteArrayOutputStream(text.length)
        while (!deflater.finished()) {
            val count = deflater.deflate(buffer)
            byteArrayOutputStream.write(buffer, 0, count)
        }
        byteArrayOutputStream.close()

        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT)
    }

    fun decompressString(compressedText: String): String {
        val compressedData = Base64.decode(compressedText, Base64.DEFAULT)
        val inflater = Inflater()
        inflater.setInput(compressedData)
        val buffer = ByteArray(1024)
        val byteArrayOutputStream = ByteArrayOutputStream(compressedData.size)
        while (!inflater.finished()) {
            val count = inflater.inflate(buffer)
            byteArrayOutputStream.write(buffer, 0, count)
        }
        byteArrayOutputStream.close()

        return String(byteArrayOutputStream.toByteArray())
    }

    open fun runWorkerTask(context: Context, info: VideoInfo, taskData: OneTimeWorkRequest) {
        val op = WorkManager.getInstance(ContextUtils.getApplicationContext())
            .cancelAllWorkByTag(info.id)
        try {
            op.result.get()
        } catch (e: Throwable) {
            e.printStackTrace()
        } finally {
            WorkManager.getInstance(context).enqueueUniqueWork(
                info.id, ExistingWorkPolicy.REPLACE, taskData
            )
        }
    }

    private fun getDownloaderPreferences(context: Context): SharedPreferences {
        return context
            .getSharedPreferences("custom_downloader", Context.MODE_PRIVATE)
    }

}
