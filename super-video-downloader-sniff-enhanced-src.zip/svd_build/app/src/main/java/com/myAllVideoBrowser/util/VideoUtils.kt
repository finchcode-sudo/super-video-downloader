package com.myAllVideoBrowser.util

import com.myAllVideoBrowser.ui.main.home.browser.ContentType
import com.myAllVideoBrowser.util.proxy_utils.OkHttpProxyClient
import okhttp3.Headers
import okhttp3.Request

class VideoUtils {
    companion object {
        fun getContentTypeByUrl(
            url: String,
            headers: Headers?,
            okHttpProxyClient: OkHttpProxyClient
        ): ContentType {
            val regex = Regex("\\.(js|css|woff|woff2|ttf|otf|eot|svg)$|^blob:")
            if (regex.containsMatchIn(url)) {
                return ContentType.OTHER
            }

            return runCatching {
                val request = Request.Builder()
                    .url(url)
                    .headers(headers ?: Headers.headersOf())
                    .get()
                    .build()

                okHttpProxyClient.getProxyOkHttpClient().newCall(request).execute()
                    .use { response ->
                        val contentTypeStr = response.header("Content-Type")

                        when {
                            contentTypeStr?.contains("mpegurl") == true -> ContentType.M3U8
                            // Enhanced: also catch HLS served as x-mpegURL / vnd.apple.mpegurl
                            contentTypeStr?.contains("apple.mpegurl", true) == true -> ContentType.M3U8
                            contentTypeStr?.contains("dash") == true -> ContentType.MPD
                            // Enhanced: MPEG-TS segment/stream content-type.
                            contentTypeStr?.contains("mp2t", true) == true -> ContentType.VIDEO
                            contentTypeStr?.contains("video") == true -> ContentType.VIDEO
                            contentTypeStr?.contains(
                                "audio",
                                ignoreCase = true
                            ) == true -> ContentType.AUDIO
                            // Enhanced: audio served under generic audio/* fallbacks.
                            contentTypeStr?.contains("mpeg", true) == true &&
                                    contentTypeStr?.contains("audio", true) == true -> ContentType.AUDIO

                            contentTypeStr?.contains("application/octet-stream") == true -> {
                                response.body.charStream().use { reader ->
                                    // Read a larger probe window: manifests can be
                                    // preceded by a BOM / whitespace or carry the
                                    // signature slightly further in.
                                    val buf = CharArray(64)
                                    val n = reader.read(buf, 0, buf.size)
                                    val content = if (n > 0) String(buf, 0, n) else ""
                                    when {
                                        content.contains("#EXTM3U", ignoreCase = true) -> ContentType.M3U8
                                        content.contains("<MPD", ignoreCase = true) -> ContentType.MPD
                                        content.trimStart().startsWith("{") &&
                                                content.contains("\"m3u8\"", true) -> ContentType.M3U8
                                        else -> ContentType.OTHER
                                    }
                                }
                            }

                            else -> ContentType.OTHER
                        }
                    }
            }.getOrDefault(ContentType.OTHER)
        }
    }
}