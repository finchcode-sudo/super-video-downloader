package com.myAllVideoBrowser.util

/**
 * Precision filters borrowed from hikerView's UrlDetector.java. Extension/
 * keyword based video detection (".m3u8" in the URL, etc.) is fast and
 * usually right, but two shapes of URL reliably fool it:
 *
 *  1. A thumbnail/preview file whose name happens to contain a video
 *     extension as a substring, e.g. "cover.mp4.jpg" or "poster.m3u8.png"
 *     (common on sites that generate preview images by appending an image
 *     extension onto the original video's filename).
 *  2. A redirector/proxy/thumbnail-service URL that just carries another
 *     URL as a query parameter, e.g. "https://site.com/go.php?url=https://
 *     example.com/video.mp4" - the outer request itself isn't media, even
 *     though "video.mp4" appears inside it.
 *
 * Run isFalsePositive(url) as an early-reject gate before treating a URL as
 * a detected video/audio candidate.
 *
 * --- Enhanced sniffing rules (this build) ---
 *  A. MEDIA_MARKERS extended with more container/stream extensions
 *     (.ts/.m4s/.f4v/.3gp/.ogv/.wmv/.mpeg/.mpg/.opus/.ogg/.aiff ...).
 *  B. Wrapper/redirector URLs are no longer dropped outright - the inner
 *     (URL-decoded) target is extracted and evaluated recursively, so a
 *     proxy that fronts a REAL media URL is still detected.
 */
object UrlMediaFilter {

    // A real video/audio extension followed by an image extension means the
    // media extension was just part of a generated filename, not the actual
    // file type - the trailing extension is the real one.
    private val TRAILING_NON_MEDIA_EXTENSIONS = listOf(
        ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".ico",
        ".txt", ".json", ".html", ".htm", ".svg", ".css", ".js",
        ".xml", ".woff", ".woff2", ".ttf", ".otf", ".eot", ".pdf"
    )

    // Enhanced: broadened set of container / segment / audio extensions.
    private val MEDIA_MARKERS = listOf(
        ".mp4", ".m3u8", ".mpd", ".flv", ".avi", ".mov", ".mkv", ".webm",
        ".mp3", ".wav", ".flac", ".m4a", ".aac",
        // --- added ---
        ".ts", ".m4s", ".m4v", ".f4v", ".f4m", ".3gp", ".3gpp", ".ogv",
        ".ogg", ".oga", ".opus", ".wmv", ".mpeg", ".mpg", ".m2ts", ".mts",
        ".aiff", ".aif", ".ape", ".wma", ".amr", ".m3u", ".m4b"
    )

    // Wrapper/redirector patterns: the request carries a URL as a query
    // param rather than being the media itself.
    private val WRAPPED_URL_MARKERS = listOf(
        ".php?url=http", "/?url=http", "?url=http", "&url=http",
        "?src=http", "&src=http", "?redirect=http", "&redirect=http",
        // --- added ---
        "?video=http", "&video=http", "?file=http", "&file=http",
        "?media=http", "&media=http", "?source=http", "&source=http",
        "?link=http", "&link=http", "?u=http", "&u=http",
        "?target=http", "&target=http", "?stream=http", "&stream=http"
    )

    fun isFalsePositive(url: String): Boolean {
        val lower = url.lowercase().substringBefore('#')

        for (wrapped in WRAPPED_URL_MARKERS) {
            val idx = lower.indexOf(wrapped)
            if (idx == -1) continue
            // Enhanced (rule B): instead of rejecting outright, extract the
            // inner URL that follows the marker and re-evaluate it. If the
            // inner payload is itself real media, this outer request is NOT
            // a false positive.
            val innerRaw = lower.substring(idx + wrapped.length - "http".length)
            val decoded = try {
                java.net.URLDecoder.decode(innerRaw, "UTF-8")
            } catch (_: Throwable) {
                innerRaw
            }
            if (hasMediaMarker(decoded)) {
                // The wrapper carries a genuine media URL -> keep it.
                return false
            }
            // Wrapper carries no media -> genuine false positive.
            return true
        }

        return false
    }

    /**
     * True if the given (already lower-cased) string contains a media
     * extension that is NOT immediately followed by a non-media extension
     * (i.e. the media marker is the real file type, not a filename substring).
     */
    private fun hasMediaMarker(string: String): Boolean {
        if (!string.startsWith("http")) return false
        val pathOnly = string.substringBefore('?')
        for (marker in MEDIA_MARKERS) {
            val idx = pathOnly.indexOf(marker)
            if (idx == -1) continue
            val afterMarker = pathOnly.substring(idx + marker.length)
            if (TRAILING_NON_MEDIA_EXTENSIONS.none { afterMarker.startsWith(it) }) {
                return true
            }
        }
        return false
    }

    /**
     * Public helper used by the URL-based detection path: a quick, network-free
     * guess that a URL *looks like* playable media, using the same (enhanced)
     * marker set as the false-positive gate. Kept consistent with
     * isFalsePositive so the two never disagree.
     */
    fun looksLikeMedia(url: String): Boolean {
        val lower = url.lowercase().substringBefore('#')
        return hasMediaMarker(lower)
    }
}